import 'package:flutter/material.dart';
import 'package:path/path.dart'; // Za rad sa SQLite putanjama
import 'package:sqflite/sqflite.dart'; // Za SQLite bazu podataka

void main() {
  runApp(CateringApp());
}

class CateringApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Catering App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Catering To-Do List'),
      ),
      body: TaskListScreen(),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (BuildContext context) => AddTaskScreen()),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class TaskListScreen extends StatefulWidget {
  @override
  _TaskListScreenState createState() => _TaskListScreenState();
}

class _TaskListScreenState extends State<TaskListScreen> {
  Database? database;
  List<Map<String, dynamic>> tasks = [];

  @override
  void initState() {
    super.initState();
    initializeDatabase();
  }

  Future<void> initializeDatabase() async {
    // Otvara bazu podataka ili je kreira ako ne postoji
    database = await openDatabase(
      join(await getDatabasesPath(), 'tasks.db'),
      onCreate: (db, version) {
        return db.execute(
          'CREATE TABLE tasks(id INTEGER PRIMARY KEY, name TEXT)',
        );
      },
      version: 1,
    );
    fetchTasks(); // Učitavanje zadataka nakon inicijalizacije baze
  }

  Future<void> fetchTasks() async {
    if (database != null) {
      final List<Map<String, dynamic>> taskList = await database!.query('tasks');
      setState(() {
        tasks = taskList;
      });
    }
  }

  Future<void> deleteTask(int id) async {
    if (database != null) {
      await database!.delete(
        'tasks',
        where: 'id = ?',
        whereArgs: [id],
      );
      fetchTasks(); // Osvježavanje liste nakon brisanja
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: tasks.length,
      itemBuilder: (BuildContext context, int index) {
        return ListTile(
          title: Text(tasks[index]['name']),
          trailing: IconButton(
            icon: Icon(Icons.delete, color: Colors.red),
            onPressed: () => deleteTask(tasks[index]['id']),
          ),
        );
      },
    );
  }
}

class AddTaskScreen extends StatefulWidget {
  @override
  _AddTaskScreenState createState() => _AddTaskScreenState();
}

class _AddTaskScreenState extends State<AddTaskScreen> {
  Database? database;
  final TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    initializeDatabase();
  }

  Future<void> initializeDatabase() async {
    database = await openDatabase(
      join(await getDatabasesPath(), 'tasks.db'),
      version: 1,
    );
  }

  Future<void> addTask(String name) async {
    if (database != null) {
      await database!.insert(
        'tasks',
        {'name': name},
        conflictAlgorithm: ConflictAlgorithm.replace,
      );
      if (mounted) {
        Navigator.pop(context); // Provjeravamo je li widget montiran prije povratka
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add New Task'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(labelText: 'Task Name'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                if (_controller.text.isNotEmpty) {
                  addTask(_controller.text);
                }
              },
              child: Text('Add Task'),
            ),
          ],
        ),
      ),
    );
  }
}
